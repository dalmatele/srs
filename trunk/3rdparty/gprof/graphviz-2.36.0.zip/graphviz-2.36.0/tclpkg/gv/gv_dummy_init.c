#include <gvc.h>

void gv_string_writer_init (GVC_t *gvc) {}
void gv_channel_writer_init (GVC_t *gvc) {}
